#win = visual.Window([600,600])
from __future__ import division  # so that 1/3=0.333 instead of 1/3=0
from psychopy import visual, core, data, event, logging, sound, gui
from psychopy.constants import *  # things like STARTED, FINISHED
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import sin, cos, tan, log, log10, pi, average, sqrt, std, deg2rad, rad2deg, linspace, asarray
from math import *
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
expName = u'checkerboard_event_hard_7T_1'  # from the Builder filename that created this script
expInfo = {'participant':'', 'session':''}
dlg = gui.DlgFromDict(dictionary=expInfo, title=expName)
if dlg.OK == False: core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + 'data/[%s]_[%s_%s]_%s' %(expInfo['date'],expInfo['participant'], expInfo['session'],expName )

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=None,
    savePickle=True, saveWideText=True,
    dataFileName=filename)
#save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp


# ##################################################################################################################################################################


change_fix_flag_hard=1
total_time= 240 #sec
dummy_trigger=60 #measurement
TR=0.1 #sec
param_duration=0.1
param_fix_duration=0.2

param=[6.3,12.8,19.3,27.8,33.3,40.3,51.6,62.3,86.6,90.6,95.6,105.2,112.7,118.2,125.4,129.7,133.7,139.5,145.1,153.9,172.8,182.4,189.9,194.1,199,204.9,211.7,221.5,226.8,233.2]
param_fix=[12.3,18.3,22.5,27.1,31.7,46.3,54.1,69.7,79.7,85.5,91.9,102.3,108.7,113.7,119.7,128.5,136.3,142.7,148.3,153.3,158.9,165.5,169.5,178.3,184.5,191.5,212.5,219.1,223.3,233.3]


# ##################################################################################################################################################################



# Create some handy timers
trialClock = core.Clock()
press1_count=0
trigger_count=0.0
press_any=0
dummy_trigger_flag=0
tt = 0
kk=-1000
kk_old=-1000
trigger_time=0
real_start_time=0

param_fix_time=0
param_time=0

param_flash_count=0
param_count=0
param_flag=0
param_fix_count=0



fix_choose =["1","2","3","4","5","6","7","8","9","A","B","C","D","E","F","G","H","J","K","L"]#20
thisExp.addData('Note', param)
thisExp.nextEntry()
thisExp.addData('Note', param_fix)
thisExp.nextEntry()

# ##################################################################################################################################################################


# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(size=(1600, 900), fullscr=True, screen=0, allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True,
    )
# store frame rate of monitor if we can measure it successfully
expInfo['frameRate']=win.getActualFrameRate()
if expInfo['frameRate']!=None:
    frameDur = 1.0/round(expInfo['frameRate'])
else:
    frameDur = 1.0/60.0 # couldn't get a reliable measure so guess


# make two wedges (in opposite contrast) and alternate them for flashing
wedgeRonC1 = visual.RadialStim(win, tex='sqrXsqr', color=1,size=2,
    visibleWedge=[0, 185], radialCycles=6, angularCycles= 10, interpolate=False,ori=0,opacity=1,
    autoLog=False)#this stim changes too much for autologging to be useful
wedgeRoffC1 = visual.RadialStim(win, tex='sqrXsqr', color=-1,size=2,
    visibleWedge=[0, 185], radialCycles=6, angularCycles= 10, interpolate=False,ori=0,opacity=1,
    autoLog=False)#this stim changes too much for autologging to be useful
wedgeLonC1 = visual.RadialStim(win, tex='sqrXsqr', color=1,size=2,
    visibleWedge=[180, 360], radialCycles=6, angularCycles= 10, interpolate=False,ori=0,opacity=1,
    autoLog=False)#this stim changes too much for autologging to be useful
wedgeLoffC1 = visual.RadialStim(win, tex='sqrXsqr', color=-1,size=2,
    visibleWedge=[180, 360], radialCycles=6, angularCycles= 10, interpolate=False,ori=0,opacity=1,
    autoLog=False)#this stim changes too much for autologging to be useful
wedgeRonC2 = visual.RadialStim(win, tex='sqrXsqr', color=0.5,size=2,
    visibleWedge=[0, 185], radialCycles=6, angularCycles= 10, interpolate=False,ori=0,opacity=1,
    autoLog=False)#this stim changes too much for autologging to be useful
wedgeRoffC2 = visual.RadialStim(win, tex='sqrXsqr', color=-0.5,size=2,
    visibleWedge=[0, 185], radialCycles=6, angularCycles= 10, interpolate=False,ori=0,opacity=1,
    autoLog=False)#this stim changes too much for autologging to be useful
wedgeLonC2 = visual.RadialStim(win, tex='sqrXsqr', color=0.5,size=2,
    visibleWedge=[180, 360], radialCycles=6, angularCycles= 10, interpolate=False,ori=0,opacity=1,
    autoLog=False)#this stim changes too much for autologging to be useful
wedgeLoffC2 = visual.RadialStim(win, tex='sqrXsqr', color=-0.5,size=2,
    visibleWedge=[180, 360], radialCycles=6, angularCycles= 10, interpolate=False,ori=0,opacity=1,
    autoLog=False)#this stim changes too much for autologging to be useful
    
    
    
wedgeRonC1s = visual.RadialStim(win, tex='sqrXsqr', color=1,size=1,
    visibleWedge=[0, 185], radialCycles=3, angularCycles= 10, interpolate=False,ori=0,opacity=1,
    autoLog=False)#this stim changes too much for autologging to be useful
wedgeRoffC1s = visual.RadialStim(win, tex='sqrXsqr', color=-1,size=1,
    visibleWedge=[0, 185], radialCycles=3, angularCycles= 10, interpolate=False,ori=0,opacity=1,
    autoLog=False)#this stim changes too much for autologging to be useful
wedgeLonC1s = visual.RadialStim(win, tex='sqrXsqr', color=1,size=1,
    visibleWedge=[180, 360], radialCycles=3, angularCycles= 10, interpolate=False,ori=0,opacity=1,
    autoLog=False)#this stim changes too much for autologging to be useful
wedgeLoffC1s = visual.RadialStim(win, tex='sqrXsqr', color=-1,size=1,
    visibleWedge=[180, 360], radialCycles=3, angularCycles= 10, interpolate=False,ori=0,opacity=1,
    autoLog=False)#this stim changes too much for autologging to be useful

center_block = visual.Circle(win, radius=0.2, units='', lineWidth=0.5, lineColor=(0, 0, 0),
    lineColorSpace='rgb', fillColor=(0,0,0), fillColorSpace='rgb', edges=1024, closeShape=True, pos=(0, 0), size=0.25, ori=0.0, opacity=1.0,
    contrast=1.0, depth=0, interpolate=False, lineRGB=None, fillRGB=None, name=None,
    autoLog=None, autoDraw=False)
    
instruction = visual.TextStim(win=win, ori=0, name='instruction',
    text=u'',font=u'Arial',
    pos=[0, 0], height=0.1, wrapWidth=None, bold=True,
    color=u'white', colorSpace='rgb', opacity=1,
    depth=-2.0)

End_instruction = visual.TextStim(win=win, ori=0, name='End_instruction',
    text=u'End this run.\n\nNext run will start soon.',    font=u'Arial',
    pos=[0, 0], height=0.1, wrapWidth=None,bold=True,
    color=u'white', colorSpace='rgb', opacity=1,
    depth=-2.0)

fixation = visual.TextStim(win=win, ori=0, name='fixation',
    text=u'+',    font=u'Arial',
    pos=[0, 0.0075], height=0.15, wrapWidth=None,
    color=u'black', colorSpace='rgb', opacity=1,
    depth=-4.0)
    
none_blank = visual.TextStim(win=win, ori=0, name='fixation',
    text=u'',    font=u'Arial',
    pos=[0, 0], height=0.1, wrapWidth=None,
    color=u'white', colorSpace='rgb', opacity=1,
    depth=-4.0)
    
    
clock_disp = visual.TextStim(win=win, ori=0, name='clock_disp',
    text=u'-',    font=u'Arial',
    pos=[0.9, -0.9], height=0.1, wrapWidth=None,
    color=u'red', colorSpace='rgb', opacity=1,
    depth=-4.0)
    
    
#------Prepare to start Routine "trial"-------
stim=none_blank
stim2=none_blank
trialClock.reset()  # clock 
# update component parameters for each repeat
keybrd_input = event.BuilderKeyResponse()  # create an object of type KeyResponse
keybrd_input.status = NOT_STARTED
# keep track of which components have finished
trialComponents = []
trialComponents.append(instruction)
trialComponents.append(keybrd_input)
trialComponents.append(fixation)
trialComponents.append(End_instruction)
trialComponents.append(clock_disp)
for thisComponent in trialComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED


#-------Start Routine "trial"-------
continueRoutine = True

while continueRoutine:
    tt = trialClock.getTime()
# wait subject response ----------------------------------------------------------------------------
    if trigger_time >= 0.0 and instruction.status == NOT_STARTED and keybrd_input.status == NOT_STARTED:
        keybrd_input.status = STARTED
        # keyboard checking is just starting
        keybrd_input.clock.reset()  # now t=0
        event.clearEvents(eventType='keyboard')
        if change_fix_flag_hard==1:
            thisExp.addData('Note', 'hard task')
            instruction.text=u'If you see "1" or "2" or "3", \nplease press the button as soon as possible. \n\nNo further question please press the button.'
        if change_fix_flag_hard==0:
            thisExp.addData('Note', 'easy task')
            instruction.text=u'If you see red cross, \nplease press the button as soon as possible. \n\nNo further question please press the button.'
        instruction.setAutoDraw(True)
        win.flip()
        
        thisExp.nextEntry()
        theseKeys = event.getKeys(keyList=['1','2','3','4','5','n'])
        while ("2" in theseKeys)==0 :
            theseKeys = event.getKeys(keyList=['1','2','3','4','5','n'])
        
        instruction.text=u'Welcome! \nPlease keep your position steady and do not move your head or body.'
        instruction.setAutoDraw(True)
        win.flip()
        
        while ("n" in theseKeys)==0 :
            theseKeys = event.getKeys(keyList=['1','2','3','4','5','n'])
        
        instruction.text=u'Please focus on the center.'
        instruction.setAutoDraw(True)
        win.flip()
        
# wait trigger and dummy scan----------------------------------------------------------------------------
    if keybrd_input.status == STARTED and dummy_trigger_flag<dummy_trigger:
        # listen key input
        theseKeys = event.getKeys(keyList=['1','2','3','4','5'])
        if "escape" in theseKeys:
            endExpNow = True
        if len(theseKeys) > 0 :
            if "5" in theseKeys:
                press_any=press_any+1
                dummy_trigger_flag=dummy_trigger_flag+1
                trigger_count=-1

                if dummy_trigger_flag==dummy_trigger:
                    trigger_count=0
                    trigger_time=0
                    real_start_time=trialClock.getTime()
                    thisExp.addData('Note', 'start time')
                    thisExp.addData('time', real_start_time)
                    thisExp.addData('real time', trialClock.getTime())
                    thisExp.nextEntry()
                    instruction.setAutoDraw(False)
                    fixation.setAutoDraw(True)
                    win.flip()

    if trigger_count>=0 and dummy_trigger_flag==dummy_trigger  and End_instruction.status == NOT_STARTED :
    # encode trigger or subject response ----------------------------------------------------------------------------
        theseKeys = event.getKeys(keyList=['1','2','3','4','5'])
        if len(theseKeys) > 0:  # at least one key was pressed
            press_any=press_any+len(theseKeys)
            if "5" in theseKeys or "5,2" in theseKeys or "2,5" in theseKeys:
                trigger_count=trigger_count+1
                trigger_time=TR*(trigger_count-1)
                stim.draw()
                stim2.draw()
                center_block.draw()
                fixation.draw()
                win.flip()
                thisExp.addData('Note', theseKeys)
                thisExp.addData('time', trigger_time)
                thisExp.addData('fix type', kk)
                thisExp.addData('stim', param_flag)
                thisExp.addData('real time', tt)
                thisExp.nextEntry()
                
                if  param_fix_count<len(param_fix) and param_fix[param_fix_count]>TR*(trigger_count)-0.001 and param_fix[param_fix_count]<TR*(trigger_count)+0.001:
                    param_fix_time=trialClock.getTime()
                    param_fix_count=param_fix_count+1
                    
                    if change_fix_flag_hard==1 :
                        kk=np.random.randint(0,3, size=1)
                        fixation.text=fix_choose[kk]
                    else:
                       kk=1
                       fixation.color=u'red'
                elif (TR*(trigger_count)-param_fix[param_fix_count-1]>=param_fix_duration-0.001 or trigger_count>0) and tt-param_fix_time+TR>=param_fix_duration-0.001: 
                   
                    param_fix_time=trialClock.getTime()
                    if change_fix_flag_hard==1:
                        kk=np.random.randint(3,20, size=1)
                        while kk_old == kk:
                            kk=np.random.randint(3,20, size=1)
                        kk_old=kk
                        fixation.text=fix_choose[kk]
                        
                    else:
                        kk=0
                        fixation.color=u'black'
                if  param_count<len(param) and param[param_count]>TR*(trigger_count)-0.001 and param[param_count]<TR*(trigger_count)+0.001 :

                    param_flag=1
                    param_time=trialClock.getTime()
                    param_count=param_count+1
                    stim = wedgeLonC1
                    stim2= wedgeRonC1
                    param_flash_count=1
                    
                elif param_flash_count<5 and TR*(trigger_count)-param[param_count-1]>=param_duration-0.001 and param_time>0:
                    param_flag=1
                    param_time=trialClock.getTime()
                    param_flash_count=param_flash_count+1
                    if param_flash_count%2==1 :
                        stim = wedgeLonC1
                        stim2= wedgeRonC1
                    else:
                        stim = wedgeLoffC1
                        stim2= wedgeRoffC1
                if  param_flash_count==5 and param_flag==1:
                    param_flag=0
                    param_flash_count==0
                    stim = none_blank
                    stim2 = none_blank
            
            elif "2" in theseKeys or "5,2" in theseKeys or "2,5" in theseKeys:
                
                thisExp.addData('Note', theseKeys)
                thisExp.addData('time', trigger_time)
                thisExp.addData('real time', tt)
                if TR*(trigger_count)-param_fix[param_fix_count-1]-param_fix_duration-TR<0.5:
                    press1_count=press1_count+1
                    thisExp.addData('correct', 1)
                thisExp.nextEntry()
            else:
                thisExp.addData('Note', theseKeys)
                thisExp.addData('time', trigger_time)
                thisExp.addData('real time', trialClock.getTime())
                thisExp.nextEntry()
        
        if endExpNow or event.getKeys(keyList=["escape"]):
            keybrd_input.status = STOPPED
            continueRoutine = False
            core.quit()
    if trigger_time>=total_time-TR  and End_instruction.status == NOT_STARTED and trigger_count>0:
        End_instruction_time = trialClock.getTime()  # underestimates by a little under one frame
        fixation.setAutoDraw(False)
        End_instruction.setAutoDraw(True)
        win.flip()
        thisExp.addData('Note', 'END')
        thisExp.addData('time', End_instruction_time)
        thisExp.nextEntry()
        thisExp.addData('Note', ['stimlus:',len(param_fix),'  press 1:',press1_count,'  trigger:',trigger_count, '  press any:', press_any])
        thisExp.nextEntry()
        print 'stimlus:',len(param_fix),'  press 1:',press1_count,'  trigger:',trigger_count, '  press any:', press_any
            
    if trigger_time>=0 and trigger_count>0 and event.getKeys(keyList=["a"]):
        fixation.setAutoDraw(False)
        End_instruction.setText(u'Correct : %d / 30 \nWrong: %d ' %(press1_count,press_any-press1_count-trigger_count-dummy_trigger))
        End_instruction.setAutoDraw(True)
        win.flip()
    if trigger_time>=0 and trigger_count>0 and event.getKeys(keyList=["r"]):
        fixation.setAutoDraw(False)
        End_instruction.setText(u'Please close your eyes and rest for 1 min.\n\nPlease keep your position steady and do not move your head or body. \n\nNext run will start soon.')
        End_instruction.setAutoDraw(True)
        win.flip()

    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        End_instruction.setAutoDraw(False)
        keybrd_input.status = STOPPED
        continueRoutine = False
        core.quit()
    

win.close()
core.quit()